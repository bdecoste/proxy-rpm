# Google Long Running Operations API

This package contains the definition of an abstract interface that
manages long running operations with API services.  See
[google.longrunning.Operations][] for details.